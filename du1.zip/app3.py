import streamlit as st
from login_page import login_page
from home_page import home_page
from ats_score_page import ats_score_page
import time  

# Configure Page
st.set_page_config(
    page_title="Auth Portal",
    page_icon="C:/Users/nialr/Downloads/internshipicon.jpg",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# Custom CSS
st.markdown(
    '''
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: 'Arial', sans-serif;
        }

        @keyframes borderLoop {
            0% { box-shadow: 0 0 5px rgba(0, 255, 0, 0.3), inset 0 0 5px rgba(0, 255, 0, 0.3); }
            25% { box-shadow: 5px 0 10px rgba(0, 255, 0, 0.8), inset -5px 0 10px rgba(0, 255, 0, 0.8); }
            50% { box-shadow: 0 5px 10px rgba(0, 255, 0, 0.8), inset 0 -5px 10px rgba(0, 255, 0, 0.8); }
            75% { box-shadow: -5px 0 10px rgba(0, 255, 0, 0.8), inset 5px 0 10px rgba(0, 255, 0, 0.8); }
            100% { box-shadow: 0 0 5px rgba(0, 255, 0, 0.3), inset 0 0 5px rgba(0, 255, 0, 0.3); }
        }

        .header-section {
            max-width: 700px;
            margin: 50px auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            animation: borderLoop 3s infinite linear;
        }

        .main-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #00ff00;
        }

        .content-wrapper {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .content-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.25rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            width: 100%;
            max-width: 600px;
            text-align: center;
            animation: borderLoop 3s infinite linear;
        }

        .content-card:hover {
            transform: translateY(-2px);
            background: rgba(255, 255, 255, 0.15);
        }
    </style>
    ''',
    unsafe_allow_html=True
)

# Initialize session state variables if not set
if 'authenticated' not in st.session_state:
    st.session_state['authenticated'] = False
if 'page' not in st.session_state:
    st.session_state['page'] = 'login'

# Navigation function
def navigate(page_name):
    st.session_state['page'] = page_name

# Header Section
st.markdown("""
    <div class="header-section">
        <h1 class="main-title">Auth Portal</h1>
        <p>Secure login & registration system.</p>
    </div>
""", unsafe_allow_html=True)

# Authentication Logic
if not st.session_state['authenticated']:
    # Show Login Page
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        if username == "admin" and password == "password":  # Replace with actual authentication
            st.session_state['authenticated'] = True
            st.session_state['page'] = 'home'
            st.success("Login successful!")
            time.sleep(1)  # Short delay before showing content
            st.experimental_rerun()
        else:
            st.error("Invalid credentials. Try again.")

else:
    # Main Content Wrapper
    st.markdown('<div class="content-wrapper">', unsafe_allow_html=True)

    # Show Navigation Options after login
    if st.button("Home"):
        navigate('home')
    if st.button("ATS Score"):
        navigate('ats_score')
    if st.button("Logout"):
        st.session_state['authenticated'] = False
        st.session_state['page'] = 'login'
        st.experimental_rerun()

    # Page Routing
    if st.session_state['page'] == 'home':
        home_page(navigate)
    elif st.session_state['page'] == 'ats_score':
        ats_score_page(navigate)

    st.markdown('</div>', unsafe_allow_html=True)  # Close content wrapper
