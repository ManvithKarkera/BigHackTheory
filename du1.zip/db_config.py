from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017/"

try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client['mydatabase']
    users_collection = db['users']
    ats_score_collection = db['ats_score']  # ✅ Make sure this line exists!
    tasks_collection = db['tasks']  # ✅ Added tasks collection for Task Scheduler
    client.server_info()
    print("Database connection established.")
except Exception as e:
    print(f"Database connection not established. Error: {e}")
    users_collection = None
    ats_score_collection = None
    tasks_collection = None
