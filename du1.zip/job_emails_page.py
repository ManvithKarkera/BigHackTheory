import streamlit as st
import imaplib
import email
from email.header import decode_header
import datetime
from typing import List, Dict, Optional

def decode_email_subject(subject: str) -> str:
    """Decode email subject to readable format"""
    decoded_list = decode_header(subject)
    decoded_subject = ""
    for content, encoding in decoded_list:
        if isinstance(content, bytes):
            decoded_subject += content.decode(encoding if encoding else 'utf-8')
        else:
            decoded_subject += content
    return decoded_subject

def fetch_job_emails(email_address: str, app_password: str, days: int = 30) -> List[Dict]:
    """Fetch job-related emails from Gmail"""
    try:
        # Connect to Gmail
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail.login(email_address, app_password)
        mail.select('inbox')

        # Calculate date for filtering
        date = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%d-%b-%Y")
        search_criteria = f'(SINCE "{date}" SUBJECT "job")'
        
        # Search for emails
        status, messages = mail.search(None, search_criteria)
        
        emails_list = []
        for num in messages[0].split():
            status, msg_data = mail.fetch(num, '(RFC822)')
            email_body = msg_data[0][1]
            email_message = email.message_from_bytes(email_body)
            
            subject = decode_email_subject(email_message['subject'])
            sender = email_message['from']
            date = email_message['date']
            
            emails_list.append({
                'subject': subject,
                'sender': sender,
                'date': date
            })
            
        mail.logout()
        return emails_list
        
    except Exception as e:
        raise Exception(f"Error fetching emails: {str(e)}")

def job_emails_page(navigate):
    st.title('Job Application Tracker')
    
    # Navigation
    col1, col2 = st.columns([1, 5])
    with col1:
        st.button('🏠 Home', on_click=lambda: navigate('home'))
    
    st.markdown("---")
    
    # Email configuration section
    with st.expander("📧 Email Configuration"):
        st.markdown("""
            ### Gmail Configuration
            To access your job-related emails, you'll need to:
            1. Use a Gmail account
            2. Create an App Password ([Instructions](https://support.google.com/accounts/answer/185833))
            3. Enter your credentials below
        """)
        
        # Email settings form
        with st.form("email_settings"):
            email_address = st.text_input("Gmail Address")
            app_password = st.text_input("App Password", type="password")
            days = st.slider("Fetch emails from last N days", 1, 90, 30)
            submit_button = st.form_submit_button("Save Settings")
            
            if submit_button:
                if not email_address or not app_password:
                    st.error("Please fill in all fields")
                else:
                    # Store in session state
                    st.session_state['email_settings'] = {
                        'email': email_address,
                        'password': app_password,
                        'days': days
                    }
                    st.success("Settings saved!")

    # Email fetching section
    if st.session_state.get('email_settings'):
        if st.button("🔄 Fetch Job Emails"):
            try:
                with st.spinner("Fetching emails..."):
                    settings = st.session_state['email_settings']
                    emails = fetch_job_emails(
                        settings['email'],
                        settings['password'],
                        settings['days']
                    )
                    
                    if emails:
                        st.markdown("### Recent Job-Related Emails")
                        
                        # Create tabs for different views
                        tab1, tab2 = st.tabs(["List View", "Timeline View"])
                        
                        with tab1:
                            for email_data in emails:
                                with st.expander(f"📨 {email_data['subject']}"):
                                    st.write(f"**From:** {email_data['sender']}")
                                    st.write(f"**Date:** {email_data['date']}")
                                    
                        with tab2:
                            # Create a timeline view
                            for email_data in emails:
                                st.markdown(f"""
                                    <div style='border-left: 2px solid #ccc; padding-left: 10px; margin: 10px 0;'>
                                        <p><strong>{email_data['date']}</strong></p>
                                        <h4>{email_data['subject']}</h4>
                                        <p>From: {email_data['sender']}</p>
                                    </div>
                                """, unsafe_allow_html=True)
                    else:
                        st.info("No job-related emails found in the specified time period.")
                        
            except Exception as e:
                st.error(f"Error: {str(e)}")
    else:
        st.info("Please configure your email settings first.")
    
    # Help section
    with st.expander("❓ Help & Tips"):
        st.markdown("""
            ### Tips for Job Application Tracking
            1. Create a separate Gmail folder for job applications
            2. Use labels to organize different application stages
            3. Set up email filters for automatic organization
            4. Keep track of application deadlines
            
            ### Common Issues
            - If emails aren't showing up, try increasing the day range
            - Make sure you're using an App Password, not your regular password
            - Check if your Gmail account has IMAP enabled
        """)