import streamlit as st
from pymongo import MongoClient

# MongoDB connection setup
client = MongoClient('mongodb://localhost:27017/')
db = client['mydatabase']
users_collection = db['users']

# Custom CSS for centered card layout
st.markdown(
    '''
    <style>
    /* Center the card on the page */
    .stApp {
        background-color: #080707; /* Dark background */
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        padding: 0;
        margin: 0;
    }
    
    /* Card styling */
    .card {
        background: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        max-width: 500px;
        width: 100%;
        color: #333;
        text-align: center;
    }

    /* Input fields */
    .stTextInput > div > input {
        border: 2px solid #1e90ff;
        border-radius: 8px;
        padding: 10px;
    }

    /* Buttons */
    .stButton > button {
        background-color: #1e90ff;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        margin-top: 20px;
        width: 100%;
    }
    
    .stButton > button:hover {
        background-color: #105f9f;
    }

    /* Select box */
    .stSelectbox label {
        color: #333;
        font-weight: bold;
    }

    /* Title styling */
    .stMarkdown h1 {
        margin-top: 0;
        color: #1e90ff;
    }
    </style>
    ''',
    unsafe_allow_html=True
)

# Card container
st.markdown('<div class="card">', unsafe_allow_html=True)

# Streamlit app for login, signup, and data view
st.title('Login & Signup Page')

# Navigation options
option = st.selectbox('Select an option', ['Sign In', 'Sign Up', 'View Users'])

if option == 'Sign Up':
    st.header('Sign Up')
    with st.form(key='signup_form'):
        signup_email = st.text_input('Email (Sign Up)', key='signup_email')
        signup_password = st.text_input('Password (Sign Up)', type='password', key='signup_password')
        signup_submit = st.form_submit_button('Sign Up')
        if signup_submit:
            if signup_email and signup_password:
                if users_collection.find_one({'email': signup_email}):
                    st.warning('User already exists. Please sign in.')
                else:
                    users_collection.insert_one({'email': signup_email, 'password': signup_password})
                    st.success('User registered successfully! Please sign in.')
            else:
                st.warning('Please enter both email and password for signup.')

elif option == 'Sign In':
    st.header('Sign In')
    with st.form(key='signin_form'):
        signin_email = st.text_input('Email (Sign In)', key='signin_email')
        signin_password = st.text_input('Password (Sign In)', type='password', key='signin_password')
        signin_submit = st.form_submit_button('Sign In')
        if signin_submit:
            if signin_email and signin_password:
                user = users_collection.find_one({'email': signin_email, 'password': signin_password})
                if user:
                    st.success('Login successful!')
                else:
                    st.error('Invalid email or password')
            else:
                st.warning('Please enter both email and password for sign in.')

elif option == 'View Users':
    st.header('Registered Users')
    users = list(users_collection.find({}, {'_id': 0}))
    if users:
        st.table(users)
    else:
        st.info('No users found in the database.')

# Example user insertion for testing purposes only
if st.button('Create Test User'):
    users_collection.insert_one({'email': 'test@example.com', 'password': 'password123'})
    st.info('Test user created with email: test@example.com and password: password123')

# Close card container
st.markdown('</div>', unsafe_allow_html=True)
