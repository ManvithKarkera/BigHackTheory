import streamlit as st
from pymongo import MongoClient
import PyPDF2
from docx import Document
from db_config import ats_score_collection
import re

def extract_text_from_pdf(file):
    pdf_reader = PyPDF2.PdfReader(file)
    text = ''
    for page in pdf_reader.pages:
        text += page.extract_text() if page.extract_text() else ''
    return text

def extract_text_from_docx(file):
    doc = Document(file)
    text = ''
    for paragraph in doc.paragraphs:
        text += paragraph.text + '\n'
    return text

def calculate_ats_score(resume_text, job_description_text):
    resume_text = resume_text.lower()
    job_description_text = job_description_text.lower()

    resume_length = len(resume_text.split())
    jd_length = len(job_description_text.split())

    keyword_matches = len([word for word in job_description_text.split() if word in resume_text])
    keyword_match_score = (keyword_matches / jd_length) * 40

    formatting_score = 0
    if re.search(r'\b(contact|experience|education|skills|projects)\b', resume_text):
        formatting_score = 60

    ats_score = keyword_match_score + formatting_score
    return ats_score, keyword_match_score, formatting_score

def ats_score_page(navigate):
    st.title('ATS Score Checker')
    
    if 'user_email' not in st.session_state:
        st.warning('Please log in to access this page.')
        if st.button('Go to Login'):
            navigate('login')
        return

    st.write('Upload your resume (PDF or DOCX) and enter the job description to get your ATS score.')

    resume_file = st.file_uploader('Upload Resume (PDF or DOCX)', type=['pdf', 'docx'])
    job_description = st.text_area('Job Description')

    if st.button('Check ATS Score'):
        if resume_file and job_description:
            try:
                if resume_file.name.endswith('.pdf'):
                    resume_text = extract_text_from_pdf(resume_file)
                elif resume_file.name.endswith('.docx'):
                    resume_text = extract_text_from_docx(resume_file)
                else:
                    st.error('Unsupported file type. Please upload a PDF or DOCX file.')
                    return

                ats_score, keyword_score, formatting_score = calculate_ats_score(resume_text, job_description)
                st.success(f'Your ATS Score: {ats_score:.2f}')
                st.write(f'Keyword Match Score: {keyword_score:.2f} / 40')
                st.write(f'Formatting Score: {formatting_score:.2f} / 60')

                improvement_tips = []
                if keyword_score < 20:
                    improvement_tips.append('Add more relevant keywords to match the job description.')
                if formatting_score < 60:
                    improvement_tips.append('Improve formatting by including sections like Contact, Experience, Education, Skills, and Projects.')

                if improvement_tips:
                    st.subheader('Improvement Tips')
                    for tip in improvement_tips:
                        st.write(f'- {tip}')
                else:
                    st.write('Your resume looks great!')

                if ats_collection is not None: 
                    ats_collection.insert_one({
                        'email': st.session_state['user_email'],
                        'ats_score': ats_score,
                        'keyword_score': keyword_score,
                        'formatting_score': formatting_score
                    })
                    st.success('ATS score saved successfully.')
                else:
                    st.error('Database connection not established.')
            
            except Exception as e:
                st.error(f'Error processing file: {e}')
        
        else:
            st.warning('Please upload a resume and enter a job description.')

    st.button('Go Back to Home', on_click=lambda: navigate('home'))
