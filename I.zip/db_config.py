from pymongo import MongoClient

MONGO_URI = "mongodb://192.168.1.8:27017/"

try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client['mydatabase']
    users_collection = db['users']
    ats_score_collection = db['ats_score']
    
    client.server_info()
    print("Database connection established.")
except Exception as e:
    print(f"Database connection not established. Error: {e}")
    users_collection = None
    ats_score_collection = None
