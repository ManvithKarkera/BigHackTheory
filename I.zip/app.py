import streamlit as st
from login_page import login_page
from home_page import home_page
from ats_score_page import ats_score_page

# Initialize the page state if not already set
if 'page' not in st.session_state:
    st.session_state['page'] = 'login'

def navigate(page_name):
    st.session_state['page'] = page_name

# Page Routing
if st.session_state['page'] == 'login':
    login_page(navigate)
elif st.session_state['page'] == 'home':
    home_page(navigate)
elif st.session_state['page'] == 'ats_score':
    ats_score_page(navigate)
